<?php
/*
PLUGIN BY: @frpitu
Github: www.github.com/frpitu

PLEASE OPEN
THE README.MD
*/
namespace Warps;

use pocketmine\Player;
use pocketmine\Server;

use pocketmine\event\Listener as L;
use pocketmine\plugin\PluginBase as P;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

use pocketmine\inventory\PlayerInventory;
use pocketmine\inventory\Inventory;
use pocketmine\event\inventory\InventoryTransactionEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\inventory\InventoryCloseEvent;
 
use pocketmine\scheduler\CallbackTask;
 
use pocketmine\utils\Config;
 
use pocketmine\level\Level;
use pocketmine\level\Position;

use pocketmine\item\Item;

use pocketmine\block\Block;

use Warps\Inventory\ChestInv;
use Warps\Inventory\WindowHolder;

class Main extends P implements L{ 
 
 public $inv = [];

 public function onEnable(){
 	$this->getServer()->getPluginManager()->registerEvents($this, $this);
  @mkdir($this->getDataFolder());
  $this->saveResource("mensagens.yml");
  $this->cfg = new Config($this->getDataFolder(). "teleports.yml", Config::YAML);
  $this->msg = new Config($this->getDataFolder()."mensagens.yml", Config::YAML);
 }
 
 public function onCommand(CommandSender $sender, Command $cmd, $lbl, array $args){
 	
 	// SET TERRENOS //

  if(strtolower($cmd->getName()) == "setlobby"){
	  $cfg = $this->cfg->getAll();
			$this->cfg->set("Lobby", [
		 "x" => $sender->getX(),
	  "y" => $sender->getY(),
	  "z" => $sender->getZ(),
  	"mundo" => $sender->getLevel()->getName(),
			]);
			$this->cfg->save();
		 $sender->sendMessage("§7Warp §9Lobby §7setado em:\n§cX: §e".$sender->getFloorX()."\n§cY: §e".$sender->getFloorY()."\n§cZ: §e".$sender->getFloorZ()."\n§cMundo: §e".$sender->getLevel()->getName());
  }
  
  // SET ARENA //
  
  if(strtolower($cmd->getName()) == "setsw"){
  	if(empty($args)){
  		$sender->sendMessage("§l§7(!) §r§9Utilize: §e/setsw <rank|normal>");
  		return true;
  	}
  	if($args[0] == "normal"){
 	  $cfg = $this->cfg->getAll();
			 $this->cfg->set("SkyWarsNormal", [
	 	 "x" => $sender->getX(),
	   "y" => $sender->getY(),
	   "z" => $sender->getZ(),
   	"mundo" => $sender->getLevel()->getName(),
		 	]);
	 		$this->cfg->save();
		  $sender->sendMessage("§7Warp §9Arena Normal §7setada em:\n§cX: §e".$sender->getFloorX()."\n§cY: §e".$sender->getFloorY()."\n§cZ: §e".$sender->getFloorZ()."\n§cMundo: §e".$sender->getLevel()->getName());
		 }
		 if($args[0] == "rank"){
 	  $cfg = $this->cfg->getAll();
			 $this->cfg->set("SkyWarsRanked", [
	 	 "x" => $sender->getX(),
	   "y" => $sender->getY(),
	   "z" => $sender->getZ(),
   	"mundo" => $sender->getLevel()->getName(),
		 	]);
	 		$this->cfg->save();
		  $sender->sendMessage("§7Warp §9SkyWars Ranked §7setada em:\n§cX: §e".$sender->getFloorX()."\n§cY: §e".$sender->getFloorY()."\n§cZ: §e".$sender->getFloorZ()."\n§cMundo: §e".$sender->getLevel()->getName());
		 }
		 }
		 
		 // SET MINA //
		 
		 if(strtolower($cmd->getName()) == "setxtra"){
  	if(empty($args)){
  		$sender->sendMessage("§l§7(!) §r§9Utilize: §e/setxtra <tntrun/uhc>");
  		return true;
  	}
  	if($args[0] == "Murder"){
 	  $cfg = $this->cfg->getAll();
			 $this->cfg->set("Murder", [
	 	 "x" => $sender->getX(),
	   "y" => $sender->getY(),
	   "z" => $sender->getZ(),
   	"mundo" => $sender->getLevel()->getName(),
		 	]);
	 		$this->cfg->save();
		  $sender->sendMessage("§7Warp §9TnTRun §7setada em:\n§cX: §e".$sender->getFloorX()."\n§cY: §e".$sender->getFloorY()."\n§cZ: §e".$sender->getFloorZ()."\n§cMundo: §e".$sender->getLevel()->getName());
		 }
		 /*if($args[0] == "hs"){
 	  $cfg = $this->cfg->getAll();
			 $this->cfg->set("HideAndSeek", [
	 	 "x" => $sender->getX(),
	   "y" => $sender->getY(),
	   "z" => $sender->getZ(),
   	"mundo" => $sender->getLevel()->getName(),
		 	]);
	 		$this->cfg->save();
		  $sender->sendMessage("§7Warp §9Hide And Seek §7setada em:\n§cX: §e".$sender->getFloorX()."\n§cY: §e".$sender->getFloorY()."\n§cZ: §e".$sender->getFloorZ()."\n§cMundo: §e".$sender->getLevel()->getName());*/
		 //}
		 if($args[0] == "uhc"){
 	  $cfg = $this->cfg->getAll();
			 $this->cfg->set("UHC", [
	 	 "x" => $sender->getX(),
	   "y" => $sender->getY(),
	   "z" => $sender->getZ(),
   	"mundo" => $sender->getLevel()->getName(),
		 	]);
	 		$this->cfg->save();
		  $sender->sendMessage("§7Warp §9UHC §7setada em:\n§cX: §e".$sender->getFloorX()."\n§cY: §e".$sender->getFloorY()."\n§cZ: §e".$sender->getFloorZ()."\n§cMundo: §e".$sender->getLevel()->getName());
		 }
  }
		
		 // SET LOJA //
		 
		 if(strtolower($cmd->getName()) == "setminigames"){
  	if(empty($args)){
  		$sender->sendMessage("§l§c(!) §r§7Utilize: §9/setminigames <bw/bridge>");
  		return true;
  	}
  	if($args[0] == "bw"){
 	  $cfg = $this->cfg->getAll();
			 $this->cfg->set("BEDWARS", [
	 	 "x" => $sender->getX(),
	   "y" => $sender->getY(),
	   "z" => $sender->getZ(),
   	"mundo" => $sender->getLevel()->getName(),
		 	]);
	 		$this->cfg->save();
		  $sender->sendMessage("§7Warp §9BedWars §7setada em:\n§cX: §e".$sender->getFloorX()."\n§cY: §e".$sender->getFloorY()."\n§cZ: §e".$sender->getFloorZ()."\n§cMundo: §e".$sender->getLevel()->getName());
		 }
		 if($args[0] == "bridge"){
 	  $cfg = $this->cfg->getAll();
			 $this->cfg->set("THEBRIDGE", [
	 	 "x" => $sender->getX(),
	   "y" => $sender->getY(),
	   "z" => $sender->getZ(),
   	"mundo" => $sender->getLevel()->getName(),
		 	]);
	 		$this->cfg->save();
		  $sender->sendMessage("§7Warp §9TheBridge §7setada em:\n§cX: §e".$sender->getFloorX()."\n§cY: §e".$sender->getFloorY()."\n§cZ: §e".$sender->getFloorZ()."\n§cMundo: §e".$sender->getLevel()->getName());
		 }
		 }
  
  // WARPS //
  
  if(strtolower($cmd->getName()) == "more"){ 
   $inv = new ChestInv($sender);
   $sender->addWindow($inv);
   $this->inv[$sender->getName()] = $inv;
   $this->sendPag($inv, "menu");
   return;
  } 
 }
 public function onClick(InventoryTransactionEvent $e){
  $trans = $e->getTransaction()->getTransactions();
  $p = $e->getTransaction()->getPlayer();
  $name = $p->getName();
  if(isset($this->inv[$name])){
   $inv = $this->inv[$name];
   foreach($trans as $action){
    $e->setCancelled();
    $item = $action->getTargetItem();
    if($item->getId() === 276){
     $this->sendPag($inv, "SwTag");
    }
    if($item->getId() === 278){
     $this->sendPag($inv, "Extras");
    }
    if($item->getId() === 2){
     $this->tpWarp($p, "Lobby");
     $this->onClose();
    }
    if($item->getId() === 264 && $item->getCustomName() === "§r§9MINIGAMES"){
     $this->sendPag($inv, "minigames");
    }
    if($item->getId() === 267){
     $this->tpWarp($p, "SkyWarsNormal");
     $this->onClose();
    }
    if($item->getId() === 20){
     $this->tpWarp($p, "SkyWarsRanked");
     $this->onClose();
    }
    if($item->getId() === 73){
     $this->tpWarp($p, "Murder");
     $this->onClose();
    }
    if($item->getId() === 21){
     $this->tpWarp($p, "HideAndSeek");
     $this->onClose();
    }
    if($item->getId() === 129){
     $this->tpWarp($p, "UHC");
     $this->onClose();
    }
    if($item->getId() === 264 && $item->getCustomName() === "§r§9BEDWARS"){
     $this->tpWarp($p, "BEDWARS");
     $this->onClose();
    }
    if($item->getId() === 388){
     $this->tpWarp($p, "THEBRIDGE");
     $this->onClose();
    }
    if($item->getId() === 262){
     $this->sendPag($inv, "menu");
    }
   }
  }
 }
 
 public function onClose(InventoryCloseEvent $ev){
  $name = $ev->getPlayer()->getName();
  if(isset($this->inv[$name])){
  unset($this->inv[$name]);
  }
 }
 
 public function onQuit(PlayerQuitEvent $ev){
  $name = $ev->getPlayer()->getName();
  if(isset($this->inv[$name])){
  unset($this->inv[$name]);
  }
 }
 
 public function sendPag($inv, $pag){
 	switch($pag){
 		case "menu":
 		$inv->clearAll();
 		$inv->setItem(10, Item::get(276)->setCustomName("§r§9SKYWARS"));
 		$inv->setItem(12, Item::get(278)->setCustomName("§r§9EXTRAS"));
 		$inv->setItem(14, Item::get(2)->setCustomName("§r§9LOBBY"));
 		$inv->setItem(16, Item::get(264)->setCustomName("§r§9MINIGAMES"));
 		break;
 		case "SwTag":
 		$inv->clearAll();
 		$inv->setItem(12, Item::get(267)->setCustomName("§r§9SKYWARS NORMAL"));
 		$inv->setItem(14, Item::get(20)->setCustomName("§r§9SKYWARS RANKED"));
 	 $inv->setItem(26, Item::get(262)->setCustomName("§r§cVoltar"));
 		break;
 		case "Extras":
 		$inv->clearAll();
 		$inv->setItem(11, Item::get(73)->setCustomName("§r§9TNTRUN"));
 		$inv->setItem(278, Item::get(21)->setCustomName("§r§9HIDE AND SEEK"));
 		$inv->setItem(15, Item::get(129)->setCustomName("§r§9UHC"));
 		$inv->setItem(26, Item::get(262)->setCustomName("§r§cVoltar"));
 		break;
 		case "minigames":
 		$inv->clearAll();
 		$inv->setItem(12, Item::get(264)->setCustomName("§r§9BEDWARS"));
 		$inv->setItem(14, Item::get(388)->setCustomName("§r§9THEBRIDGE"));
 		$inv->setItem(26, Item::get(262)->setCustomName("§r§cVoltar"));
 		break;
 	}
 }
 
 public function tpWarp($p, $warp){
 	switch($warp){
 		case "Lobby":
 		$cfg = $this->cfg->getAll();
 		$msg = $this->msg->getAll();
   $pos = new Position($cfg["Lobby"]["x"],$cfg["Lobby"]["y"],$cfg["Lobby"]["z"],$this->getServer()->getLevelByName($cfg["Lobby"]["mundo"]));
$this->getServer()->loadLevel($cfg["Lobby"]["mundo"]);
$p->teleport($pos);
$p->sendMessage($msg["msg.teleportado.lobby"]);
 		break;
 		case "SkyWarsNormal":
 		$cfg = $this->cfg->getAll();
 		$msg = $this->msg->getAll();
   $pos = new Position($cfg["SkyWarsNormal"]["x"],$cfg["SkyWarsNormal"]["y"],$cfg["SkyWarsNormal"]["z"],$this->getServer()->getLevelByName($cfg["SkyWarsNormal"]["mundo"]));
$this->getServer()->loadLevel($cfg["SkyWarsNormal"]["mundo"]);
$p->teleport($pos);
$p->sendMessage($msg["msg.teleportado.sw.normal"]);
 		break;
 		case "SkyWarsRanked":
 		$cfg = $this->cfg->getAll();
 		$msg = $this->msg->getAll();
   $pos = new Position($cfg["SkyWarsRanked"]["x"],$cfg["SkyWarsRanked"]["y"],$cfg["SkyWarsRanked"]["z"],$this->getServer()->getLevelByName($cfg["SkyWarsRanked"]["mundo"]));
$this->getServer()->loadLevel($cfg["SkyWarsRanked"]["mundo"]);
$p->teleport($pos);
$p->sendMessage($msg["msg.teleportado.sw.ranked"]);
 		break;
 		case "Murder":
 		$cfg = $this->cfg->getAll();
 		$msg = $this->msg->getAll();
   $pos = new Position($cfg["TnTRun"]["x"],$cfg["TnTRun"]["y"],$cfg["TnTRun"]["z"],$this->getServer()->getLevelByName($cfg["TnTRun"]["mundo"]));
$this->getServer()->loadLevel($cfg["TnTRun"]["mundo"]);
$p->teleport($pos);
$p->sendMessage($msg["msg.teleportado.tnt.run"]);
 		break;
 		/*case "HideAndSeek":
 		$cfg = $this->cfg->getAll();
 		$msg = $this->msg->getAll();
   $pos = new Position($cfg["HideAndSeek"]["x"],$cfg["HideAndSeek"]["y"],$cfg["HideAndSeek"]["z"],$this->getServer()->getLevelByName($cfg["HideAndSeek"]["mundo"]));
$this->getServer()->loadLevel($cfg["HideAndSeek"]["mundo"]);
$p->teleport($pos);
$p->sendMessage($msg["msg.teleportado.hide.and.seek"]);*/
 		case "UHC":
 		$cfg = $this->cfg->getAll();
 		$msg = $this->msg->getAll();
   $pos = new Position($cfg["UHC"]["x"],$cfg["UHC"]["y"],$cfg["UHC"]["z"],$this->getServer()->getLevelByName($cfg["UHC"]["mundo"]));
$this->getServer()->loadLevel($cfg["UHC"]["mundo"]);
$p->teleport($pos);
$p->sendMessage($msg["msg.teleportado.uhc"]);
 		break;
 		case "BEDWARS":
 		$cfg = $this->cfg->getAll();
 		$msg = $this->msg->getAll();
   $pos = new Position($cfg["BEDWARS"]["x"],$cfg["BEDWARS"]["y"],$cfg["BEDWARS"]["z"],$this->getServer()->getLevelByName($cfg["BEDWARS"]["mundo"]));
$this->getServer()->loadLevel($cfg["BEDWARS"]["mundo"]);
$p->teleport($pos);
$p->sendMessage($msg["msg.teleportado.bedwars"]);
 		break;
 		case "THEBRIDGE":
 		$cfg = $this->cfg->getAll();
 		$msg = $this->msg->getAll();
   $pos = new Position($cfg["THEBRIDGE"]["x"],$cfg["THEBRIDGE"]["y"],$cfg["THEBRIDGE"]["z"],$this->getServer()->getLevelByName($cfg["THEBRIDGE"]["mundo"]));
$this->getServer()->loadLevel($cfg["THEBRIDGE"]["mundo"]);
$p->teleport($pos);
$p->sendMessage($msg["msg.teleportado.thebridge"]);
 		break;
 	}
 }
}